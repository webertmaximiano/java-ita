/**
 * 
 */
/**
 * 
 */
module ComponentGamification {
	requires junit;
	
	requires org.mockito;
	requires org.junit.jupiter.api;
}